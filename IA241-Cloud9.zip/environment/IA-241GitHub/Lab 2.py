'''
lab 2
'''


#3.1
my_name = "Tom"
print(my_name)

#3.2
my_id = 123
print(my_id)

#3.3

#_123=my_id
my_id = your_id=123
print(my_id)
print(your_id)

#3.4

my_id_str = '123'
print(my_id_str)

#3.5

# print(my_name + my_id) 

#3.6

print(my_name + my_id_str) 

#3.7

print(my_name*3) 

#3.8

print('hello, world. this is my first python string.'.split('.')) 

#3.9

message = "Tom's id is 123"
print(message) 